﻿namespace KnowledgeMining.UI.Services.Search
{

    public partial class FacetGraphGenerator
    {
        public class FDGraphEdges
        {
            public int source { get; set; }
            public int target { get; set; }
            public int distance { get; set; }
        }
    }
}
