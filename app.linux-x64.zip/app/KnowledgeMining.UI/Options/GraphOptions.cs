﻿namespace KnowledgeMining.UI.Options
{
    public class GraphOptions
    {
        public const string Graph = "Graph";

        public string Facets { get; set; }
    }
}
