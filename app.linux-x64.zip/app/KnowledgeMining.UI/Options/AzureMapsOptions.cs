﻿namespace KnowledgeMining.UI.Options
{
    public class AzureMapsOptions
    {
        public const string AzureMaps = "AzureMaps";

        public string SubscriptionKey { get; set; }
    }
}
