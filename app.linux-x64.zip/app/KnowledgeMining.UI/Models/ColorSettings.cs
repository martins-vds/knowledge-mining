﻿namespace KnowledgeMining.UI.Models
{
    public class ColorSettings
    {
        public string BackgroundColor { get; set; } = "#ffffff";
        public string TextColor { get; set; } = "#4A4A4A";
    }
}